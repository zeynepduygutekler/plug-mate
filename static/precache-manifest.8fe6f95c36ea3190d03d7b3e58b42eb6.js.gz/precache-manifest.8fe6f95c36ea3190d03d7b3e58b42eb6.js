self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ed2e240c90dfc9d90ab89877600375dd",
    "url": "/index.html"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "736f15c6f550def38c17",
    "url": "/static/css/main.08d852bc.chunk.css"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/js/2.536b2d3b.chunk.js"
  },
  {
    "revision": "736f15c6f550def38c17",
    "url": "/static/js/main.92c7f90c.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);