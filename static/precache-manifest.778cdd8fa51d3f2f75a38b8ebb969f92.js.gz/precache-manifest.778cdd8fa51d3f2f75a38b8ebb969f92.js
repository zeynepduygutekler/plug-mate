self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "da0948f9c1f95b22420661eca35887d2",
    "url": "/index.html"
  },
  {
    "revision": "c6e9095a7d4db9872f2d",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "c2071ccda543d1130ae0",
    "url": "/static/css/main.682f9cbb.chunk.css"
  },
  {
    "revision": "c6e9095a7d4db9872f2d",
    "url": "/static/js/2.ac8d8d87.chunk.js"
  },
  {
    "revision": "c2071ccda543d1130ae0",
    "url": "/static/js/main.a41a5942.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);