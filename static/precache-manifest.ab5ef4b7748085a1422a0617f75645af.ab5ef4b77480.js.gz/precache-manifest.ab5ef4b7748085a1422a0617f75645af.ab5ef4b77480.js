self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4e96f54ba63029561a0e32befc9a4b00",
    "url": "/index.html"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "c0f728b0095df58f9914",
    "url": "/static/css/main.08d852bc.chunk.css"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/js/2.536b2d3b.chunk.js"
  },
  {
    "revision": "c0f728b0095df58f9914",
    "url": "/static/js/main.008f3a11.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);