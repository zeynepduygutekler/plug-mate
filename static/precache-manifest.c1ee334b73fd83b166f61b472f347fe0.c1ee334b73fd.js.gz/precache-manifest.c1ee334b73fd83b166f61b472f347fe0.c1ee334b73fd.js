self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "68af01bac1ddf24cc732203d90ad2ece",
    "url": "/index.html"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "9337c342692d2965cdbb",
    "url": "/static/css/main.08d852bc.chunk.css"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/js/2.536b2d3b.chunk.js"
  },
  {
    "revision": "9337c342692d2965cdbb",
    "url": "/static/js/main.c4d2e7f4.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);