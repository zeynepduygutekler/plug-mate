self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b5b61f5b0574488d74bec1caeeb95616",
    "url": "/index.html"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "ba14becae7c50e6d7211",
    "url": "/static/css/main.08d852bc.chunk.css"
  },
  {
    "revision": "352a554e19738ccce9ed",
    "url": "/static/js/2.536b2d3b.chunk.js"
  },
  {
    "revision": "ba14becae7c50e6d7211",
    "url": "/static/js/main.09e769b1.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);