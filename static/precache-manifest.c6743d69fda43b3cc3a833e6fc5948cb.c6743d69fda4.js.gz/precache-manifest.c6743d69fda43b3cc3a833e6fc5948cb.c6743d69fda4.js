self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "049ab8c86d93fa94ceb4bd92b3bb4849",
    "url": "/index.html"
  },
  {
    "revision": "99f70b6d6c954cc3c296",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "d118588cc811f514bbed",
    "url": "/static/css/main.ec071929.chunk.css"
  },
  {
    "revision": "99f70b6d6c954cc3c296",
    "url": "/static/js/2.073cdfd9.chunk.js"
  },
  {
    "revision": "d118588cc811f514bbed",
    "url": "/static/js/main.0768edfd.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);