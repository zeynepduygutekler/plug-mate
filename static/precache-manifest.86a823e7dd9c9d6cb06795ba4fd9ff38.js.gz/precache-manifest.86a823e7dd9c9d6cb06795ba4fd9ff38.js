self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ef393faf8205219c09d7759c0a585fdf",
    "url": "/index.html"
  },
  {
    "revision": "cb960baa217e4eb84e36",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "80b9aeb56e30f58fef0a",
    "url": "/static/css/main.ec071929.chunk.css"
  },
  {
    "revision": "cb960baa217e4eb84e36",
    "url": "/static/js/2.84fbc5cd.chunk.js"
  },
  {
    "revision": "80b9aeb56e30f58fef0a",
    "url": "/static/js/main.e106d0f4.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);