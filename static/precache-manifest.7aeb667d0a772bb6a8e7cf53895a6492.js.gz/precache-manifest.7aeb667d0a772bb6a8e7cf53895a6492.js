self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "585b91a0aae5828064020b4b3944c7d0",
    "url": "/index.html"
  },
  {
    "revision": "99f70b6d6c954cc3c296",
    "url": "/static/css/2.bf8e2397.chunk.css"
  },
  {
    "revision": "6d82002a443db6ff49d2",
    "url": "/static/css/main.ec071929.chunk.css"
  },
  {
    "revision": "99f70b6d6c954cc3c296",
    "url": "/static/js/2.073cdfd9.chunk.js"
  },
  {
    "revision": "6d82002a443db6ff49d2",
    "url": "/static/js/main.40dfcfce.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);